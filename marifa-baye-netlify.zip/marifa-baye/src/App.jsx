import { useState, useEffect, useCallback } from "react";

const C = {
  ink: "#1A1A2E", parch: "#F7F3EC", gold: "#C9952A",
  goldLt: "#E8C96A", teal: "#1B6B6B", rose: "#8B3A3A",
};

const CAT = {
  aqida:    { bg:"rgba(27,107,107,0.22)",  border:"rgba(27,107,107,0.45)", text:"#6ECECE", label:"ʿAqīda" },
  fiqh:     { bg:"rgba(201,149,42,0.18)",  border:"rgba(201,149,42,0.38)", text:"#E8C96A", label:"Fiqh" },
  tasawwuf: { bg:"rgba(139,58,58,0.22)",   border:"rgba(139,58,58,0.42)",  text:"#F0A8A8", label:"Taṣawwuf" },
  suluk:    { bg:"rgba(90,60,140,0.22)",   border:"rgba(90,60,140,0.42)",  text:"#C8A8F0", label:"Sulūk" },
  sira:     { bg:"rgba(60,100,40,0.22)",   border:"rgba(60,100,40,0.42)",  text:"#A8D890", label:"Sīra" },
};

/* ══ API ══ */
async function callClaude(prompt) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 800,
      messages: [{ role: "user", content: prompt }]
    })
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`API ${res.status}: ${err}`);
  }
  const data = await res.json();
  const raw = data.content.map(b => b.text || "").join("").trim();
  const clean = raw.replace(/^```(?:json)?\s*/i,"").replace(/\s*```\s*$/,"").trim();
  const jsonMatch = clean.match(/\{[\s\S]*\}/);
  if (!jsonMatch) throw new Error("No JSON found in: " + clean.slice(0,200));
  return JSON.parse(jsonMatch[0]);
}

/* ══ PROMPTS — compact, tout-en-un ══ */
function quizPrompt(lvl) {
  const lvlName = ["débutant","intermédiaire","avancé"][lvl-1];
  return `Tu es expert des livres de Cheikh Ibrahim Niass (Baye Niass 1900-1975): Kashif al-Ilbas, Kanz al-Masun, Jawaahir al-Rasail, Ruwah al-Arwah, Sawaaih al-Ilham, Sirr al-Asrar, Mishkat al-Anwar, Tanbih al-Ghafilin, Iqaz al-Himam, Al-Dawha al-Mushtabika, Nafaaat al-Udhn, Al-Khalas al-Muhimm.

Génère 1 question de quiz niveau ${lvlName} sur ces livres (noms, contenus, concepts: Fayda Tijaniyya, Tarbiyya, Fanaa, Wusul, Wird Tijani).

Réponds UNIQUEMENT JSON valide (pas de texte, pas de backticks):
{"category":"tasawwuf","categoryLabel":"Taṣawwuf","arabic":"كاشف الإلباس","question":"Question?","choices":["A","B","C","D"],"correct":0,"explanation":"Explication 2 phrases."}

correct = index 0-3 de la bonne réponse. Catégories: aqida, fiqh, tasawwuf, suluk, sira.`;
}

function flashPrompt(lvl) {
  const lvlName = ["débutant","intermédiaire","avancé"][lvl-1];
  return `Tu es expert des livres de Cheikh Ibrahim Niass (Baye Niass 1900-1975): Kashif al-Ilbas, Kanz al-Masun, Jawaahir al-Rasail, Ruwah al-Arwah, Sawaaih al-Ilham, Sirr al-Asrar, Mishkat al-Anwar, Tanbih al-Ghafilin, Iqaz al-Himam, Al-Dawha al-Mushtabika.

Génère 1 flashcard niveau ${lvlName} (définition, livre, concept, date ou personnage).

Réponds UNIQUEMENT JSON valide (pas de texte, pas de backticks):
{"category":"tasawwuf","categoryLabel":"Taṣawwuf","arabic":"الفيضة","front":"Question ou terme?","back":"Réponse claire 3-4 phrases mentionnant le livre."}

Catégories: aqida, fiqh, tasawwuf, suluk, sira.`;
}

/* ══ SUB-COMPONENTS ══ */
function Spinner() {
  return (
    <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:14,padding:"44px 0"}}>
      <div style={{
        width:40,height:40,borderRadius:"50%",
        border:"3px solid rgba(201,149,42,0.15)",
        borderTopColor:C.gold,
        animation:"spin 0.85s linear infinite"
      }}/>
      <div style={{color:C.goldLt,opacity:0.65,fontSize:13}}>Génération par l'IA…</div>
    </div>
  );
}

function Badge({cat}) {
  const info = CAT[cat] || CAT.aqida;
  return (
    <div style={{
      display:"inline-block",padding:"4px 13px",borderRadius:12,
      fontSize:11,fontWeight:600,letterSpacing:"0.1em",textTransform:"uppercase",
      marginBottom:14,background:info.bg,border:`1px solid ${info.border}`,color:info.text
    }}>{info.label}</div>
  );
}

/* ══ MAIN ══ */
export default function App() {
  const [mode,setMode]           = useState("quiz");
  const [level,setLevel]         = useState(1);
  const [loading,setLoading]     = useState(false);
  const [errorMsg,setErrorMsg]   = useState(null);
  const [question,setQuestion]   = useState(null);
  const [card,setCard]           = useState(null);
  const [selected,setSelected]   = useState(null);
  const [showFb,setShowFb]       = useState(false);
  const [flipped,setFlipped]     = useState(false);
  const [score,setScore]         = useState(0);
  const [answered,setAnswered]   = useState(0);
  const [streak,setStreak]       = useState(0);
  const [sessionQ,setSessionQ]   = useState(0);
  const [showModal,setShowModal] = useState(false);

  const load = useCallback(async (m, l) => {
    setLoading(true); setErrorMsg(null);
    setQuestion(null); setCard(null);
    setSelected(null); setShowFb(false); setFlipped(false);
    try {
      if (m === "quiz") {
        const q = await callClaude(quizPrompt(l));
        setQuestion(q);
      } else {
        const fc = await callClaude(flashPrompt(l));
        setCard(fc);
      }
    } catch(e) {
      setErrorMsg(e.message || "Erreur inconnue");
    }
    setLoading(false);
  }, []);

  useEffect(() => { load("quiz", 1); }, []);

  const choose = (idx) => {
    if (selected !== null) return;
    setSelected(idx); setShowFb(true);
    const ok = idx === question.correct;
    const ns = ok ? streak + 1 : 0;
    const pts = ok ? level * 10 + (ns > 1 ? (ns-1)*5 : 0) : 0;
    setScore(s => s+pts);
    setAnswered(a => a+1);
    setStreak(ns);
    const nq = sessionQ + 1; setSessionQ(nq);
    if (nq >= 10) setTimeout(() => setShowModal(true), 700);
  };

  const rateFlash = (good) => {
    if (good) { setScore(s => s + level*5); setStreak(k => k+1); }
    else setStreak(0);
    setAnswered(a => a+1);
    const nq = sessionQ + 1; setSessionQ(nq);
    if (nq >= 10) { setShowModal(true); return; }
    load(mode, level);
  };

  const switchMode = (m) => { setMode(m); setSessionQ(0); load(m, level); };
  const changeLevel = (l) => { setLevel(l); setSessionQ(0); load(mode, l); };
  const reset = () => {
    setScore(0); setAnswered(0); setStreak(0); setSessionQ(0);
    setShowModal(false); load(mode, level);
  };

  const pct = Math.min((sessionQ/10)*100, 100);

  return (
    <div style={{
      minHeight:"100vh", background:C.ink, color:C.parch,
      fontFamily:"'Inter',sans-serif", padding:"0 0 60px",
      backgroundImage:`radial-gradient(circle at 20% 20%,rgba(201,149,42,0.06) 0%,transparent 50%),
        radial-gradient(circle at 80% 80%,rgba(27,107,107,0.07) 0%,transparent 50%)`
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&family=Noto+Naskh+Arabic:wght@400;600&family=Inter:wght@300;400;500;600&display=swap');
        @keyframes spin { to{transform:rotate(360deg)} }
        @keyframes fadeUp { from{opacity:0;transform:translateY(6px)} to{opacity:1;transform:translateY(0)} }
        .hov:hover{opacity:0.85}
      `}</style>

      <div style={{maxWidth:740,margin:"0 auto",padding:"0 14px"}}>

        {/* HEADER */}
        <div style={{textAlign:"center",padding:"32px 0 20px"}}>
          <div style={{fontFamily:"'Noto Naskh Arabic',serif",fontSize:"clamp(24px,5vw,40px)",color:C.gold,textShadow:"0 2px 18px rgba(201,149,42,0.28)",lineHeight:1.4}}>
            مَعْرِفَة — كُتُبُ بَايَ نِيَاسٍ
          </div>
          <div style={{fontFamily:"'Amiri',serif",fontSize:"clamp(15px,2.8vw,20px)",opacity:0.78,marginTop:4}}>
            Ma'rifa — Livres de Baye Niass
          </div>
          <div style={{width:60,height:2,background:`linear-gradient(90deg,transparent,${C.gold},transparent)`,margin:"14px auto 0"}}/>
        </div>

        {/* STATS */}
        <div style={{display:"flex",gap:8,justifyContent:"center",flexWrap:"wrap",marginBottom:18}}>
          {[["✦ Score",score],["📖 Répondues",answered],["🌟 Série",streak]].map(([l,v])=>(
            <div key={l} style={{background:"rgba(201,149,42,0.09)",border:"1px solid rgba(201,149,42,0.2)",borderRadius:20,padding:"5px 13px",fontSize:12,color:C.goldLt,display:"flex",gap:5,alignItems:"center"}}>
              {l} : <strong style={{color:C.gold}}>{v}</strong>
            </div>
          ))}
        </div>

        {/* TABS */}
        <div style={{display:"flex",gap:8,justifyContent:"center",marginBottom:18}}>
          {[["quiz","Quiz ⚡"],["flash","Flashcards 🃏"]].map(([m,label])=>(
            <button key={m} className="hov" onClick={()=>switchMode(m)} style={{
              padding:"9px 24px",borderRadius:30,border:"none",cursor:"pointer",
              fontSize:14,fontWeight:500,
              background:mode===m?C.gold:"rgba(255,255,255,0.06)",
              color:mode===m?C.ink:C.parch,
              boxShadow:mode===m?"0 3px 14px rgba(201,149,42,0.32)":"none",
              outline:mode!==m?"1px solid rgba(255,255,255,0.1)":"none"
            }}>{label}</button>
          ))}
        </div>

        {/* LEVELS */}
        <div style={{textAlign:"center",fontSize:11,color:C.goldLt,opacity:0.5,letterSpacing:"0.12em",textTransform:"uppercase",marginBottom:9}}>Niveau</div>
        <div style={{display:"flex",gap:8,justifyContent:"center",flexWrap:"wrap",marginBottom:20}}>
          {[[1,"🌱 Débutant","#2A6B3A","#A8DFB0","#3A8B4A","#3A9B5A"],
            [2,"🔥 Intermédiaire","#1B5070","#8DCFF0","#2A78A8","#2A78A8"],
            [3,"⚡ Avancé","#6B2A2A","#F0A8A8","#A83A3A","#A83A3A"]
          ].map(([l,label,bg,text,border,activeBg])=>(
            <button key={l} className="hov" onClick={()=>changeLevel(l)} style={{
              padding:"6px 16px",borderRadius:20,border:`1px solid ${border}`,
              cursor:"pointer",fontSize:12,fontWeight:500,
              background:level===l?activeBg:bg, color:text,
              boxShadow:level===l?"0 2px 10px rgba(0,0,0,0.28)":"none"
            }}>{label}</button>
          ))}
        </div>

        {/* PROGRESS */}
        <div style={{marginBottom:16}}>
          <div style={{height:3,background:"rgba(255,255,255,0.07)",borderRadius:2,overflow:"hidden"}}>
            <div style={{height:"100%",borderRadius:2,width:`${pct}%`,background:`linear-gradient(90deg,${C.teal},${C.gold})`,transition:"width 0.4s ease"}}/>
          </div>
          <div style={{textAlign:"right",fontSize:11,color:C.goldLt,opacity:0.5,marginTop:4}}>{sessionQ} / 10</div>
        </div>

        {/* CARD */}
        <div style={{
          background:"rgba(247,243,236,0.042)",border:"1px solid rgba(201,149,42,0.17)",
          borderRadius:18,padding:"24px 18px",
          boxShadow:"0 8px 36px rgba(0,0,0,0.28)",minHeight:280,
          animation:"fadeUp 0.3s ease"
        }}>

          {loading && <Spinner/>}

          {!loading && errorMsg && (
            <div style={{textAlign:"center",padding:"30px 0"}}>
              <div style={{color:"#F0A8A8",fontSize:13,marginBottom:6}}>⚠ Erreur :</div>
              <div style={{color:"rgba(240,168,168,0.7)",fontSize:11,marginBottom:18,wordBreak:"break-all",maxWidth:400,margin:"0 auto 18px"}}>{errorMsg}</div>
              <button className="hov" onClick={()=>load(mode,level)} style={{
                padding:"10px 22px",borderRadius:30,border:`1px solid rgba(201,149,42,0.3)`,
                background:"transparent",color:C.goldLt,cursor:"pointer",fontSize:14
              }}>Réessayer</button>
            </div>
          )}

          {/* QUIZ */}
          {!loading && !errorMsg && mode==="quiz" && question && (
            <div style={{animation:"fadeUp 0.3s ease"}}>
              <Badge cat={question.category}/>
              {question.arabic && (
                <div style={{fontFamily:"'Noto Naskh Arabic',serif",fontSize:18,color:C.goldLt,opacity:0.72,textAlign:"right",direction:"rtl",marginBottom:10}}>
                  {question.arabic}
                </div>
              )}
              <div style={{fontFamily:"'Amiri',serif",fontSize:"clamp(15px,2.4vw,19px)",lineHeight:1.72,marginBottom:18}}>
                {question.question}
              </div>
              <div style={{display:"flex",flexDirection:"column",gap:8}}>
                {question.choices.map((c,i)=>{
                  const done = selected !== null;
                  const isOk = i === question.correct;
                  const isSel = selected === i;
                  let bg="rgba(255,255,255,0.05)", border="rgba(255,255,255,0.1)", col=C.parch;
                  if(done && isOk)            {bg="rgba(42,148,90,0.17)"; border="#2A9A5A"; col="#A8F0C0";}
                  if(done && isSel && !isOk)  {bg="rgba(180,50,50,0.17)"; border="#B43232"; col="#F0A8A8";}
                  return (
                    <button key={i} className="hov" onClick={()=>choose(i)} disabled={done} style={{
                      background:bg,border:`1px solid ${border}`,borderRadius:11,
                      padding:"11px 14px",cursor:done?"default":"pointer",
                      fontSize:13,color:col,textAlign:"left",
                      display:"flex",alignItems:"center",gap:10,transition:"all 0.18s"
                    }}>
                      <span style={{width:24,height:24,borderRadius:"50%",flexShrink:0,
                        background:"rgba(201,149,42,0.13)",border:"1px solid rgba(201,149,42,0.26)",
                        display:"flex",alignItems:"center",justifyContent:"center",
                        fontSize:11,fontWeight:600,color:C.gold}}>{"ABCD"[i]}</span>
                      {c}
                    </button>
                  );
                })}
              </div>
              {showFb && (
                <div style={{
                  marginTop:16,padding:"13px 16px",borderRadius:11,fontSize:13,lineHeight:1.6,
                  animation:"fadeUp 0.25s ease",
                  background:selected===question.correct?"rgba(42,148,90,0.1)":"rgba(180,50,50,0.1)",
                  border:`1px solid ${selected===question.correct?"rgba(42,148,90,0.28)":"rgba(180,50,50,0.28)"}`,
                  color:selected===question.correct?"#A8F0C0":"#F0A8A8"
                }}>
                  {selected===question.correct?"✦ Excellent ! ":"✗ Pas tout à fait. "}
                  <span style={{color:"rgba(247,243,236,0.7)",fontSize:12}}>{question.explanation}</span>
                </div>
              )}
              {showFb && sessionQ < 10 && (
                <div style={{textAlign:"center",marginTop:18}}>
                  <button className="hov" onClick={()=>load(mode,level)} style={{
                    padding:"11px 28px",borderRadius:30,border:"none",
                    background:C.gold,color:C.ink,fontWeight:600,
                    cursor:"pointer",fontSize:13,
                    boxShadow:"0 3px 14px rgba(201,149,42,0.32)"
                  }}>Question suivante →</button>
                </div>
              )}
            </div>
          )}

          {/* FLASHCARD */}
          {!loading && !errorMsg && mode==="flash" && card && (
            <div style={{animation:"fadeUp 0.3s ease"}}>
              <Badge cat={card.category}/>
              <div style={{
                borderRadius:13,padding:"24px 18px",textAlign:"center",cursor:"pointer",
                background:flipped?"linear-gradient(135deg,rgba(27,107,107,0.12),rgba(201,149,42,0.06))":"linear-gradient(135deg,rgba(201,149,42,0.07),rgba(27,107,107,0.07))",
                border:`1px solid ${flipped?"rgba(27,107,107,0.3)":"rgba(201,149,42,0.2)"}`,
                minHeight:200,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",
                transition:"background 0.4s ease, border 0.4s ease"
              }} onClick={()=>setFlipped(f=>!f)}>
                <div style={{fontSize:10,letterSpacing:"0.2em",textTransform:"uppercase",color:flipped?C.teal:C.gold,opacity:0.55,marginBottom:12}}>
                  {flipped?"Réponse":"Question"}
                </div>
                {!flipped && card.arabic && (
                  <div style={{fontFamily:"'Noto Naskh Arabic',serif",fontSize:"clamp(18px,3vw,26px)",color:C.gold,direction:"rtl",marginBottom:10}}>
                    {card.arabic}
                  </div>
                )}
                <div style={{fontFamily:"'Amiri',serif",fontSize:"clamp(14px,2.2vw,17px)",lineHeight:1.75,color:C.parch}}>
                  {flipped ? card.back : card.front}
                </div>
                {!flipped && <div style={{fontSize:11,color:C.goldLt,opacity:0.4,marginTop:16}}>Toucher pour révéler</div>}
              </div>
              {flipped && (
                <div style={{display:"flex",gap:10,justifyContent:"center",marginTop:16,animation:"fadeUp 0.25s ease"}}>
                  <button className="hov" onClick={()=>rateFlash(false)} style={{
                    padding:"10px 20px",borderRadius:30,border:`1px solid rgba(201,149,42,0.28)`,
                    background:"transparent",color:C.goldLt,cursor:"pointer",fontSize:13
                  }}>😓 Difficile</button>
                  <button className="hov" onClick={()=>rateFlash(true)} style={{
                    padding:"10px 22px",borderRadius:30,border:"none",
                    background:C.gold,color:C.ink,fontWeight:600,
                    cursor:"pointer",fontSize:13,
                    boxShadow:"0 3px 12px rgba(201,149,42,0.3)"
                  }}>✓ Je sais !</button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* BOTTOM BTNS */}
        <div style={{display:"flex",gap:10,justifyContent:"center",marginTop:16,flexWrap:"wrap"}}>
          <button className="hov" onClick={()=>load(mode,level)} style={{
            padding:"10px 22px",borderRadius:30,border:`1px solid rgba(201,149,42,0.28)`,
            background:"transparent",color:C.goldLt,cursor:"pointer",fontSize:13
          }}>↺ Nouvelle question</button>
          <button className="hov" onClick={()=>setShowModal(true)} style={{
            padding:"10px 22px",borderRadius:30,border:`1px solid rgba(201,149,42,0.28)`,
            background:"transparent",color:C.goldLt,cursor:"pointer",fontSize:13
          }}>📊 Mon score</button>
        </div>
      </div>

      {/* MODAL */}
      {showModal && (
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.7)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:100,backdropFilter:"blur(5px)"}}>
          <div style={{background:"#1E1E38",border:`1px solid rgba(201,149,42,0.26)`,borderRadius:22,padding:"36px 28px",maxWidth:380,width:"90%",textAlign:"center",boxShadow:"0 18px 56px rgba(0,0,0,0.56)"}}>
            <div style={{fontSize:46,marginBottom:12}}>{score>=200?"🌟":score>=100?"🔥":score>=50?"📖":"🌱"}</div>
            <div style={{fontFamily:"'Amiri',serif",fontSize:20,color:C.gold,marginBottom:6}}>Résultats</div>
            <div style={{fontSize:50,fontWeight:700,color:C.parch}}>{score}</div>
            <div style={{fontSize:12,color:C.goldLt,opacity:0.6,margin:"6px 0 18px"}}>{answered} cartes • série : {streak}</div>
            <div style={{fontSize:13,color:C.parch,opacity:0.78,lineHeight:1.65,marginBottom:22}}>
              {score>=200?"Māshāʾ Allāh ! Tu maîtrises vraiment les œuvres de Baye Niass !":
               score>=100?"Très bien ! Tu progresses dans la connaissance des livres.":
               score>=50?"Bien démarré ! Continue, chaque question est une perle.":
               "C'est un début béni ! La Mujāhada est la clé. Continue !"}
            </div>
            <div style={{display:"flex",gap:10,justifyContent:"center"}}>
              <button className="hov" onClick={()=>setShowModal(false)} style={{padding:"10px 24px",borderRadius:30,border:"none",background:C.gold,color:C.ink,fontWeight:600,cursor:"pointer",fontSize:13}}>Continuer →</button>
              <button className="hov" onClick={reset} style={{padding:"10px 20px",borderRadius:30,border:`1px solid rgba(201,149,42,0.28)`,background:"transparent",color:C.goldLt,cursor:"pointer",fontSize:13}}>Recommencer</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
