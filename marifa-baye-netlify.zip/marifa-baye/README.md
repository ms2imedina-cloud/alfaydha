# مَعْرِفَة — Ma'rifa : Livres de Baye Niass

Jeu d'apprentissage islamique pour maîtriser les œuvres du Cheikh Ibrahim Niass (Baye Niass).
Quiz + Flashcards · 3 niveaux progressifs · Propulsé par l'IA.

---

## Déploiement sur Netlify (5 étapes)

### 1. Crée un compte Netlify
→ https://app.netlify.com/signup  
Utilise ton email ou connecte-toi avec Google.

### 2. Prépare le dossier
Décompresse le fichier ZIP téléchargé.  
Tu obtiens un dossier `marifa-baye/` avec cette structure :
```
marifa-baye/
├── index.html
├── package.json
├── vite.config.js
├── netlify.toml
├── public/
│   └── favicon.svg
└── src/
    ├── main.jsx
    └── App.jsx
```

### 3. Déploie sur Netlify
**Option A — Glisser-déposer (le plus simple) :**
1. Va sur https://app.netlify.com
2. Clique sur **"Add new site"** → **"Deploy manually"**
3. Glisse le dossier `marifa-baye/` dans la zone indiquée
4. Attends 1-2 minutes → ton site est en ligne !

**Option B — Via GitHub (recommandé pour les mises à jour) :**
1. Crée un repo GitHub et pousse le dossier
2. Sur Netlify → "Add new site" → "Import from Git"
3. Connecte ton repo → Build command: `npm run build` → Publish: `dist`

### 4. Personnalise le nom du site
Dans Netlify → Site settings → Change site name  
Ex: `marifa-baye-niass.netlify.app`

### 5. Partage le lien !
Envoie le lien dans tous tes groupes WhatsApp et Telegram Taalibé Baye 🤲

---

## Personnalisation

Pour ajouter des questions fixes (sans IA), modifie `src/App.jsx`.  
Pour changer les couleurs, modifie l'objet `C` en haut du fichier.

---

*Que Allah récompense tous ceux qui apprennent et transmettent la science de Baye Niass.*  
*اللهم صل على سيدنا محمد الفاتح لما أغلق*
